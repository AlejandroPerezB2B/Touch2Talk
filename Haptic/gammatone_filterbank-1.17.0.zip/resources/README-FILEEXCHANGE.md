NOTE: this function is now available from the IoSR Matlab Toolbox as iosr.auditory.gammatoneFast.  
-------------------------   
bm = gammatoneFast(x,cfs,fs)   
bm = gammatoneFast(...,align)   
[bm,env] = gammatoneFast(...)   
[bm,env,delay] = gammatoneFast(...)

This function takes an input vector and passes it through a bank of fourth-order gammatone filters, with centre frequencies specified by cfs. The function returns a matrix, with each row/column corresponding to a filter output with a centre frequency determined by the corresponding element in cfs. The orientation of the output is determined by the orientation of the input: if x is a row vector then the output will contain one row for each filter output, and vice versa.

Centre frequencies may be any value below the Nyquist rate (determined by the sampling frequency fs). Typically centre frequencies are equally spaced on the ERB-rate scale and may be calculated thus:

cfs = MakeErbCFs(low\_cf,high\_cf,numchans)

where low\_cf is the lowest frequency in the bank, high\_cf is the highest, and numchans is the numbers of filters in the bank.

bm = gammatoneFast(...,align) allows phase alignment to be applied. With align=false, no alignment is applied (default). With align=true, fine structure and envelope alignment is applied so that the impulse response peaks occurs at t=0.

[bm,env] = gammatoneFast(...) returns the instantaneous envelopes env for each filter.

[bm,env,delay] = gammatoneFast(...) returns the delay (in samples) removed by the phase alignment of each gammatone filter, i.e. delays(n)=0 if align=false. delay is a vector the same size as cfs.

Based on code written by ZZ Jin, adapted by DLW in Jan'07 and JF Woodruff in Nov'08

See also MakeErbCFs.